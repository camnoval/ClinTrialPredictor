"""domain layer."""
