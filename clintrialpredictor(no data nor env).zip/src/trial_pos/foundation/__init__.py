"""foundation layer."""
